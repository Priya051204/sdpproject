import React from 'react'
import './accessories.css';
import { Link } from 'react-router-dom';

import accessoriesImage1 from './images2/accessoriesImage1.jpg';
import accessoriesImage2 from './images2/accessoriesImage2.jpg';
import accessoriesImage3 from './images2/accessoriesImage3.jpg';
import accessoriesImage4 from './images2/accessoriesImage4.jpg';
import accessoriesImage5 from './images2/accessoriesImage5.jpg';
import accessoriesImage6 from './images2/accessoriesImage6.jpg';
import accessoriesImage7 from './images2/accessoriesImage7.jpg';
import accessoriesImage8 from './images2/accessoriesImage8.jpg';
import accessoriesImage9 from './images2/accessoriesImage9.jpg';
import accessoriesImage10 from './images2/accessoriesImage10.jpg';

export default function About() {
  return (
    <div className="image-grid">
      <div className="image-container">
        <img src={accessoriesImage1} alt="Accessories" />
        <div className="product-info">
          <span className="product-cost">₹569</span>
          <Link to="/payment"><button className="buy-button">Buy</button></Link>
        </div>
      </div>
      <div className="image-container">
        <img src={accessoriesImage2} alt="Accessories" />
        <div className="product-info">
          <span className="product-cost">₹2000</span>
          <Link to="/payment"><button className="buy-button">Buy</button></Link>
        </div>
      </div>
      <div className="image-container">
        <img src={accessoriesImage3} alt="Accessories" />
        <div className="product-info">
          <span className="product-cost">₹789</span>
          <Link to="/payment"><button className="buy-button">Buy</button></Link>
        </div>
      </div>
      <div className="image-container">
        <img src={accessoriesImage4} alt="Accessories" />
        <div className="product-info">
          <span className="product-cost">₹890</span>
          <Link to="/payment"><button className="buy-button">Buy</button></Link>
        </div>
      </div>
      <div className="image-container">
        <img src={accessoriesImage5} alt="Accessories" />
        <div className="product-info">
          <span className="product-cost">₹690</span>
          <Link to="/payment"><button className="buy-button">Buy</button></Link>
        </div>
      </div>
      <div className="image-container">
        <img src={accessoriesImage6} alt="Accessories" />
        <div className="product-info">
          <span className="product-cost">₹350</span>
          <Link to="/payment"><button className="buy-button">Buy</button></Link>
        </div>
      </div>
      <div className="image-container">
        <img src={accessoriesImage7} alt="Accessories" />
        <div className="product-info">
          <span className="product-cost">₹870</span>
          <Link to="/payment"><button className="buy-button">Buy</button></Link>
        </div>
      </div>
      <div className="image-container">
        <img src={accessoriesImage8} alt="Accessories" />
        <div className="product-info">
          <span className="product-cost">₹1699</span>
          <Link to="/payment"><button className="buy-button">Buy</button></Link>
        </div>
      </div>
      <div className="image-container">
        <img src={accessoriesImage9} alt="Accessories" />
        <div className="product-info">
          <span className="product-cost">₹564</span>
          <Link to="/payment"><button className="buy-button">Buy</button></Link>
        </div>
      </div>
      <div className="image-container">
        <img src={accessoriesImage10} alt="Accessories" />
        <div className="product-info">
          <span className="product-cost">₹429</span>
          <Link to="/payment"><button className="buy-button">Buy</button></Link>
        </div>
      </div>
    </div>
  )
}
