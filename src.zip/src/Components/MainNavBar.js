import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import './NavBar.css'; // Import the CSS file
import Home from './Home';
import About from './About';
import Contact from './Contact';
import Accessories from './Accessories';
import AdminLogin from './../admin/AdminLogin';
import SellerLogin from '../Sellers/SellerLogin';
import CustomerLogin from './../Customer/CustomerLogin';
import Login from '../Login';
import CustomerRegistration from './../Customer/CustomerRegistration';
import SellerRegistration from './../Sellers/SellerRegistration';
import Registration from '../Registration';
import Payment from './Payment';
import logo from './images2/logo.jpg';

export default function MainNavBar() {
  return (
    <div>
      <nav>
      <div className="logo">
        <img src={logo} alt="Logo" width="65" height="65" /> {/* Use the logo image */}
      </div>
        <ul>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/about">About</Link></li>
          {/* <li><Link to="/sellerregistration">Seller Registration</Link></li>
          <li><Link to="/customerregistration">Customer Registration</Link></li> */}
          {/* <li><Link to="/CustomerLogin">Customer Login</Link></li>
          <li><Link to="/SellerLogin">Seller Login</Link></li>
          <li><Link to="/adminlogin">Admin Login</Link></li> */}
          <li><Link to="/contact">Contact</Link></li>
          <li><Link to="/accessories">Accessories</Link></li>
          <li><Link to="/login">Login</Link></li>
          <li><Link to="/registration">Registration</Link></li>
        </ul>
      </nav>

      <Routes>
        <Route path='/' element={<Home />} exact />
        <Route path='/about' element={<About />} exact />
        <Route path='/sellerregistration' element={<SellerRegistration />} exact />
        <Route path='/customerregistration' element={<CustomerRegistration />} exact />
        <Route path='/CustomerLogin' element={<CustomerLogin />} exact />
        <Route path='/SellerLogin' element={<SellerLogin />} exact />
        <Route path='/contact' element={<Contact />} exact />
        <Route path='/adminlogin' element={<AdminLogin />} exact />
        <Route path='/accessories' element={<Accessories />} exact />
        <Route path='/login' element={<Login />} exact />
        <Route path='/payment' element={<Payment />} exact />
        <Route path='/registration' element={<Registration />} exact />
      </Routes>
    </div>
  );
}
