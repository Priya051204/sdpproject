import React from 'react'

export default function About() {
  return (
    <div>
        <h4>This website is user friendly and connects pet adopter and seller of pets efficiently</h4>
        <h4>This website also provides all the necessary tools and accessories which take care of the paw friends.</h4>
    </div>
  )
}
