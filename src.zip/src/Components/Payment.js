import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode.react';
import './Payment.css';

const Payment = () => {
  const [paymentStatus, setPaymentStatus] = useState(null); // null: initial state, 'success', 'failure'
  const [paymentInfo, setPaymentInfo] = useState(null); // Payment information to encode in QR code

  // Function to handle payment
  const handlePayment = () => {
    // Simulate payment processing
    // For demonstration, randomly simulate success or failure
    const isSuccess = Math.random() < 0.5;
    if (isSuccess) {
      setPaymentStatus('success');
    } else {
      setPaymentStatus('failure');
    }
  };

  // Function to generate payment information and set it to state
  const generatePaymentInfo = () => {
    // Generate payment information (e.g., amount, transaction ID)
    const paymentData = {
      amount: 100, // Example amount
      transactionId: '123456789', // Example transaction ID
    };
    // Set the payment information to state
    setPaymentInfo(paymentData);
  };

  // Generate payment information when component mounts
  useEffect(() => {
    generatePaymentInfo();
  }, []);

  // Function to handle click on QR code image
  const handleQRCodeClick = () => {
    // Redirect to the PhonePe or Google Pay URL
    // Replace 'phonepe://' or 'googlepay://' with the actual deep link URLs for PhonePe or Google Pay
    window.location.href = 'phonepe://';
    // Alternatively, use the following for Google Pay:
    // window.location.href = 'googlepay://';
  };

  return (
    <div className="payment-container">
      <h2>Payment Page</h2>
      <div className="qr-code" onClick={handleQRCodeClick}>
        {/* Render QR code with payment information */}
        {paymentInfo && (
          <QRCode value={JSON.stringify(paymentInfo)} />
        )}
      </div>
      <button className="payment-button" onClick={handlePayment}>Make Payment</button>
      {/* Render payment status message */}
      {paymentStatus === 'success' && (
        <div className="success-message">Payment successful!</div>
      )}
      {paymentStatus === 'failure' && (
        <div className="failure-message">Payment failed. Please try again.</div>
      )}
    </div>
  );
};

export default Payment;
