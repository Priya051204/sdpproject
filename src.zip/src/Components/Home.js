import React from 'react'

export default function Home() {
  return (
    <div>
        <h4>I am in Home Page</h4>
        
    </div>
  )
}
