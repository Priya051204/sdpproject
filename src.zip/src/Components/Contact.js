import React from 'react'

export default function Contact() {
  return (
    <div>
        <h4>For any queries mail us to petspaws@gmail.com</h4> 
    </div>
  )
}
