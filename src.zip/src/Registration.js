import React from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import './Components/NavBar.css';
import CustomerRegistration from './Customer/CustomerRegistration';
import SellerRegistration from './Sellers/SellerRegistration';

export default function Login() {
  const location = useLocation(); // Get current location

  return (
    <div>
      <nav>
        <ul>
          <li><Link to="/customerregistration" className={location.pathname === '/customerregistration' ? 'active' : 'registration-link'}>CustomerRegistration</Link></li>
          <li><Link to="/sellerregistration" className={location.pathname === '/sellerregistration' ? 'active' : 'registration-link'}>SellerRegistration</Link></li>
        </ul>
      </nav>

      <Routes>
        <Route path='/customerregistration' element={<CustomerRegistration/>} exact/>
        <Route path='/sellerregistration' element={<SellerRegistration/>} exact/>
      </Routes>
    </div>
  );
}
