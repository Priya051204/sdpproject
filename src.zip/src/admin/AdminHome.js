import React from 'react'

export default function AdminHome() {
  return (
    <div>
        <h4>I am in Admin Home Page</h4>
    </div>
  )
}