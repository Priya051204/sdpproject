import React from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import './Components/NavBar.css';
import CustomerLogin from './Customer/CustomerLogin';
import SellerLogin from './Sellers/SellerLogin';
import AdminLogin from './admin/AdminLogin';

export default function Login() {
  const location = useLocation(); // Get current location

  return (
    <div>
      <nav>
        <ul>
          <li><Link to="/customerlogin" className={location.pathname === '/customerlogin' ? 'active' : 'login-link'}>CustomerLogin</Link></li>
          <li><Link to="/sellerlogin" className={location.pathname === '/sellerlogin' ? 'active' : 'login-link'}>SellerLogin</Link></li>
          <li><Link to="/adminlogin" className={location.pathname === '/adminlogin' ? 'active' : 'login-link'}>AdminLogin</Link></li>
        </ul>
      </nav>

      <Routes>
        <Route path='/customerlogin' element={<CustomerLogin/>} exact/>
        <Route path='/adminlogin' element={<AdminLogin/>} exact/>
        <Route path='/sellerlogin' element={<SellerLogin/>} exact/>
      </Routes>
    </div>
  );
}
